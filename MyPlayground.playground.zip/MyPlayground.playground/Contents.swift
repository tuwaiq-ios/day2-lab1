import UIKit
var  x = 20
var  c = 10

var  sum=x+c


print (sum)


var arrary = [0,1,2,3,4,5]


arrary.append(6)


print (arrary)


arrary.remove(at: 2)


var ahmed : Set = [2,3,4,5]


print("ahmed")


var Ahmed : String = "man"


print(ahmed)































